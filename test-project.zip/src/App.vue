<script setup>
import { ref } from "vue";
import colors from './assets/color.json';

let score = ref(0);
let start = ref(false);
let countdown = ref(60);
let gameEnd = ref(false);
let shuffledColors = [];
let timer;

const startGame = () => {
    if (start.value) return;

    start.value = true;
    gameEnd.value = false;
    timer = setInterval(() => {
        if (countdown.value === 0) {
            resetGame();
            gameEnd.value = true;
            return;
        }
        countdown.value--;
    }, 1000);
};

const resetGame = () => {
    score.value = 0;
    start.value = false;
    countdown.value = 60;
    clearInterval(timer);
};

const randomColor = () => {
    let selectedColors = [];
    let color = colors[Math.floor(Math.random() * colors.length)];
    for (let i = 0; i < 9; i++) {
        if (selectedColors.length < 8) {
            selectedColors.push(color.wrongColor);
        } else {
            selectedColors.push(color.rightColor);
            break;
        }
    }
    return selectedColors;
}

const getRandomColor = () => {
    let randomColors = randomColor();
    shuffledColors = randomColors.sort(() => Math.random() - 0.5);
    return shuffledColors;
}

const getScore = () => {
    return score.value;
}

const checkAnswer = (color) => {
    for (let i = 0; i < colors.length; i++) {
        if (color === colors[i].rightColor) {
            score.value++;
            break;
        }
    }
    shuffledColors = getRandomColor();
}

</script>

<template>
    <div class="w-screen">
        <div class="w-full flex flex-col items-center">
            <p class="text-center text-lg font-bold mt-5">Score: {{ score }}</p>
            <div class="flex flex-row mb-5 mt-10 gap-10 items-center">
                <button class="btn" @click="startGame">start game</button>
                <p class="font-mono text-6xl">{{ countdown }}</p>
                <button class="btn" @click="resetGame">reset game</button>
            </div>

            <div class="w-full flex flex-col text-center" v-show="gameEnd">
                <p class="text-2xl font-bold">Congrats, the game is over!</p>
                <p class="text-2xl font-bold">your score is {{ getScore() }}</p>
            </div>

            <div class="grid grid-cols-3 text-center" v-show="start">
                <div v-for="(color, index) in getRandomColor()" :key="index"
                    :class="`rounded-full w-28 h-28 m-5 text-center font-mono text-3xl ${color}`"
                    @click="checkAnswer(`${color}`)">
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>

</style>